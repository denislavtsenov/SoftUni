package softuni.exam.models.dto;

import javax.validation.constraints.NotNull;

public class ConstellationBaseDto {

    private Long id;
}
