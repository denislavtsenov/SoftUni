package softuni.exam.models.entity;

public enum Genre {

    CLASSIC_LITERATURE,
    SCIENCE_FICTION,
    FANTASY;
}
