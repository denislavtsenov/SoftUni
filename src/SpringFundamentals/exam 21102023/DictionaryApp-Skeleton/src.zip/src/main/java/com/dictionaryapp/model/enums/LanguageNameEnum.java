package com.dictionaryapp.model.enums;

public enum LanguageNameEnum {
    GERMAN, SPANISH, FRENCH, ITALIAN
}
