package magicGame.models.region;

import magicGame.models.magicians.Magician;
import magicGame.models.magics.Magic;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RegionImpl implements Region {

    @Override
    public String start(Collection<Magician> magicians) {
//
//        List<Magician> wizardsList = magicians.stream().filter(magician -> magician.getClass().getSimpleName()
//                .equals("Wizard")).collect(Collectors.toList());
//
//        List<Magician> blackWidowsList = magicians.stream().filter(magician -> magician.getClass().getSimpleName().equals("BlackWidow"))
//                .collect(Collectors.toList());
//
//        while (!wizardsList.isEmpty() && !blackWidowsList.isEmpty()) {
//
//
//        }

        return null;
    }
}
